package com.example.demohibernate;

import org.hibernate.annotations.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
@Table(appliesTo = "Customers")
public class Customer {
	@Id
	@GeneratedValue 
	private int id;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private int customerNumber;

	/**
	 * Al menos debe de haber estos dos constructores, 
	 * uno sin parámetros, y otro con todos los atributos.
	 */
	
	public Customer() {
	}

	public Customer(String fname, String lname, int custNum) {
		this.firstName = fname;
		this.lastName = lname;
		this.customerNumber = custNum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String first_name) {
		this.firstName = first_name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String last_name) {
		this.lastName = last_name;
	}

	public int getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}

}
