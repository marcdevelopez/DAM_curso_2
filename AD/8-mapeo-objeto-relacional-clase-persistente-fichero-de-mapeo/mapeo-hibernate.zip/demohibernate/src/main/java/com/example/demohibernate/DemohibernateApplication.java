package com.example.demohibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.*;
import org.hibernate.Transaction;
import org.hibernate.mapping.List;
import org.hibernate.query.Query;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemohibernateApplication {

	public static SessionFactory sessionFactory = null;
	public static Session session = sessionFactory.openSession();
	public static Transaction transaction = null;

	public static void main(String[] args) {
		SpringApplication.run(DemohibernateApplication.class, args);

		try {
			transaction = session.beginTransaction();
			// Aquí realizaríamos operaciones
			transaction.commit();
		}

		/**
		 * Si la sesión lanzara una excepción, se debería de hacer roll-back de la
		 * transacción y la sesión descartada.
		 */
		catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}

		/**
		 * ejemplo de consulta HQL
		 */
		String hql = "FROM Customer";
		Query consulta = session.createQuery(hql);
		consulta.setFirstResult(1);
		consulta.setMaxResults(40);
		List results = (List) consulta.list();
	}

	@SuppressWarnings("deprecation")
	public void ejemploUpdateHQLCustomer(int id, int customerNumber, String firstName) {
		// instanciamos nuestro objeto session
		Session session = sessionFactory.openSession();
		// iniciamos una transacción
		Transaction transaction = session.beginTransaction();
		// con el propio objeto session y su método createQuery, asignamos 		
		// a una variable de tipo Query la consulta HQL que vamos a 			
		// preparar.
		Query consulta = session.createQuery(
				// vamos a persistir sobre la tabla “Customer”
				"update Customer " + 
				// disponemos de tres parámetros:
				// con el primero ‘seteamos’ el valor a la columna 
				// “CUSTOMERNUMBER”
		        "set CUSTOMERNUMBER=:customerNumber " +
		    	// el segundo y el tercero entran dentro de la cláusula WHERE, 
		    	// donde filtramos por id para que se haga coincidir con el 105, y
		    	// “firstName”, para que sea “Pepe”.
		        "where ID=:id and FIRSTNAME=:firstName");
		/**
		 * update en la entidad Customer y en la columna, “customerNumber”
		 * para establecer en este campo el número 25 como número de cliente, 
		 * siempre y cuando su “Id” sea 105 y cuando su “firstName” sea “Pepe”
		 */
		consulta.setParameter("customerNumber", 2);
		consulta.setParameter("id", 27);
		consulta.setParameter("firstName", "Marcos");
		
		// Se ejecuta la query y guardamos el valor resultante en una 
		// variable de tipo entero, si es 1, quiere decir que ha sido 
		// persistida una tabla, y, por tanto, es correcto. 
		int status = consulta.executeUpdate();
		transaction.commit();
		// Si devuelve positivo habrá logrado con éxito el Query
		if (status > 0)
			System.out.println("Update realizado");
		else
			System.out.println("Update no realizado");
	}

}
