package com.example.demohibernate;

import org.hibernate.annotations.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
@Table(appliesTo = "Vehiculo")
public class Vehiculo {
	@Id
	@GeneratedValue
	private int id;
	@Column
	private String marca;
	@Column
	private String motor;
	@Column
	private int numeroRuedas;
	@Column
	private int numeroKilometros;

	/**
	 * Al menos debe de haber estos dos constructores, 
	 * uno sin parámetros, y otro con todos los atributos.
	 */
	
	public Vehiculo() {
	}

	public Vehiculo(String marca, String motor, int numeroRuedas, int numeroKilometros) {
		this.marca = marca;
		this.motor = motor;
		this.numeroRuedas = numeroRuedas;
		this.numeroKilometros = numeroKilometros;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}

	public int getNumeroRuedas() {
		return numeroRuedas;
	}

	public void setNumeroRuedas(int numeroRuedas) {
		this.numeroRuedas = numeroRuedas;
	}

	public int getNumeroKilometros() {
		return numeroKilometros;
	}

	public void setNumeroKilometros(int numeroKilometros) {
		this.numeroKilometros = numeroKilometros;
	}
}
